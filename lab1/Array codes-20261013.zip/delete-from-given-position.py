# Python program to delete an element from a given  
# position of an array
"student id =2024 "
arr = [10, 20, 30, 40, 50, 60, 70]
pos = 2

print("My student id is :202410545323")
for num in arr:
    print(num, end=" ")

# Delete the element at the specified position
del arr[pos - 1]

print("\nArray after deletion")
for num in arr:
    print(num, end=" ")