arr = [10, 20, 30, 40]
element = 50
print("Array before insertion")
for i in range(len(arr)):
	print(arr[i], end=" ")

# Insert element at the beginning
arr.insert(4, element)

print("\nArray after insertion")
for i in range(len(arr)):
    print(arr[i], end=" ")