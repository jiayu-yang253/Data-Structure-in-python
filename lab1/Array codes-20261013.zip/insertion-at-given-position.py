 #Python program to insert given element at a given position
# in an array using in-built methods

if __name__ == "__main__":
    arr = [10, 20, 30, 40]
    ele = 50
    pos = 2
    print("Array before insertion")
    print(arr)

    # Insert element at the given position
    arr.insert(pos - 1, ele)

    print("Array after insertion")
    print(arr)  