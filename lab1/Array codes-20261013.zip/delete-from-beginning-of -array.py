# Python program to delete an element from the beginning 
# of an array using custom method

if __name__ == "__main__":
    arr = [10, 20, 30, 40]
    n = len(arr)
  
    print("Array before deletion")
    for i in range(n):
        print(arr[i], end=" ")

    # Shift all the elements 1 position to the left
    # starting from second element
    for i in range(1, n):
        arr[i - 1] = arr[i]
	
    # Reduce the array size by 1
    n -= 1

    print("\nArray after deletion")
    for i in range(n):
        print(arr[i], end=" ")     