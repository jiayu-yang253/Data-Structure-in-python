# Python program to delete an element from the end 
# of an array using in-built methods

arr = [10, 20, 30, 40]

print("Array before deletion")
for ele in arr:
    print(ele, end=" ")

# Remove the last element from the array
arr.pop()

print("\nArray after deletion")
for ele in arr:
    print(ele, end=" ")