# PYthon Code:
stack = [] # creating an empty list as a stack

print(len(stack)) # Prints 0 since the stack is empty

stack.append(10) # This appends 1 to the stack
stack.append(20) # This appends 2 to the stack
print(len(stack)) # Prints 2 since the stack contains two elements

stack.append(4) # This appends 3 to the stack
print(len(stack)) # Prints 3 since the stack contains three element


