stack = []

stack.append(1) # This pushes 1 to the stack top
stack.append(2) # This pushes 2 to the stack top
stack.append(3) # This pushes 3 to the stack top
stack.append(4) # This pushes 4 to the stack top
stack.append(5) # This pushes 5 to the stack top

# Now, let us remove elements from the stack using pop function
while stack:
    print(stack[-1], end=" ")
    stack.pop() # removes the top element from the stack
    print(stack)