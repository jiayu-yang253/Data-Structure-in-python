# Custom stack implementation in Python 
class Stack:
# Constructor to initialize the stack
 def __init__(self, size):
   self.arr = [None] * size 
   self.capacity = size 
   self.top = -1


# Function to add an element `x` to the stack 

 def push(self, x):
   if self.isFull():
    print("Stack Overflow!! Calling exit()...") 
    exit(1)
   print("Inserting", x, "into the stack...") 
   self.top = self.top + 1 
   self.arr[self.top] = x


# Function to pop a top element from the stack 
 def pop(self):
# check for stack underflow 
   if self.isEmpty():
     print("Stack Underflow!! Calling exit()...") 
     exit(1)
   print("Removing", self.peek(), "from the stack")


#decrease stack size by 1 and (optionally) return the popped element
   top = self.arr[self.top]
   self.top = self.top - 1
   return top


# Function to return the top element of the stack 
 def peek(self):
  if self.isEmpty(): 
      exit(1)
  return self.arr[self.top]


# Function to return the size of the stack 

 def size(self):
  return self.top + 1
# Function to check if the stack is empty or not 

 def isEmpty(self):
  return self.size() == 0

# Function to check if the stack is full or not 
 def isFull(self):
  return self.size() == self.capacity


if __name__ == '__main__':
   
    a = Stack(3)
    
    a.push(1) 
    a.push(2)
    
    a.pop() 
    a.pop()
    
    a.push(3)


# Inserting 1 in the stack # Inserting 2 in the stack
# removing the top element (2) # removing the top element (1)
# Inserting 3 in the stack
print("Top element is", a.peek()) 
print("The stack size is", a.size())
a.pop() # removing the top element (3)
# check if the stack is empty 
if a.isEmpty():
  print("The stack is empty") 
else:
  print("The stack is not empty")