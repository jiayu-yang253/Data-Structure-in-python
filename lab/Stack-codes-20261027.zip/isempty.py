# Python Code:
def isEmpty(s):
    isStackEmpty = len(s) == 0 # checking whether stack is empty or 
                               # not and storing it into isStackEmpty variable
    return isStackEmpty # returning bool value stored in isStackEmpty

s = []

# The if - else conditional statements below prints "Stack is empty."
if isEmpty(s):
    print("Stack is empty.")
else:
    print("Stack is not empty.")

s.append(1) # Inserting value 1 to the stack top

# The if - else conditional statements below prints "Stack is not empty."
if isEmpty(s):
    print("Stack is empty.")
else:
    print("Stack is not empty.")
    
# This code is contributed by Sakshi
